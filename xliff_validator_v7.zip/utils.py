import os
import re

# Detect if running in ChatGPT environment (which uses /mnt/data/)
if os.path.exists("/mnt/data/"):
    TEST_FILES_PATH = "/mnt/data/"
else:
    TEST_FILES_PATH = "../test-files/"

def make_validation_issue(
    validator,
    message,
    filename,
    line,
    column_start,
    column_end,
    unit_id,
    text
):
    """
    Validation Issues

    Validation issues are reported as a structure that includes:
    - Validator name (which validator found the issue, this should be a short name)
    - Validator message (a message which indicates exactly what went wrong, not just "problem" or "issue" or "mismatch")
    - File name (not full file path, just the name) the issue was detected in
    - Line Number the issue was detected on
    - Column range (start and end) that identify the start and end column of line that caused the issue
    - Unit ID that the line is part of, if the problem happened within the context of a containing unit element
    - The actual text of the line that the validation issue was found on

    Constructing Validation Issue Objects

    Because validation issues have strict requirements on things like knowing line numbers, column ranges, etc any 
    third-party tools used (like XML or HTML validators) must be able to report line and column numbers, and configured
    propertly to do so. When a third party tool returns issues, the information needed to construct a validation issue 
    object must be extracted from the object returned by the third party tool. Thinks like the unit id will need to be
    computed based on line number, because the third-party tool will be unaware of XLIFF standard.

    Displaying Validation Issues

    If they are in ChatGPT chat they should be rendered in a tabular form. When displaying the actual text of the line 
    that caused the error, that text should be shown using Markdown code formatting (backticks) to highlight the issue. 
    For readability this can be shortened by truncating leading or trailing part of the line and replacing it with ellipses (`...`),
    but only if necessary due to line length. If used, the ellipsis should indicate that part of the line has been omitted:
    - Use `...` at the start of the line if the leading portion is trimmed.
    - Use `...` at the end of the line if the trailing portion is trimmed.
    - Do not add ellipses unless truncation is actually done.
    - The middle section should preserve and clearly show the problematic content.
    
    If displayed from a command-line, they should be displayed as an ASCII art table with fixed width columns. 
    Instead of highlighting the area in yellow that caused the issue, enclose the problem range between >>> and <<<
    """
    return {
        "validator": validator,
        "message": message,
        "filename": filename,
        "line": line,
        "column_range": [column_start, column_end],
        "unit_id": unit_id,
        "text": text
    }


def compare_format_lines(source_lines, target_lines, filename, unit_id, base_line_number, validator_name):
    """
    Compare two aligned lists of lines (source and target) for format consistency.

    This function checks:
    - That the line counts match
    - That leading and trailing whitespace on each line match
    - That the starting XML tag on each line matches, with allowance for <source>/<target> and </source>/</target> equivalency

    Parameters:
        source_lines (list of str): Lines from the source block.
        target_lines (list of str): Lines from the target block.
        filename (str): The name of the file being validated.
        unit_id (str): The unit ID associated with the block.
        base_line_number (int): Line number used in reporting issues.
        validator_name (str): The name of the validation check.

    Returns:
        list: A list of validation issue dictionaries (possibly empty).
    """
    issues = []

    if len(source_lines) != len(target_lines):
        issues.append(make_validation_issue(
            validator=validator_name,
            message=f"Mismatch in line count: source={len(source_lines)} lines, target={len(target_lines)} lines.",
            filename=filename,
            line=base_line_number,
            column_start=1,
            column_end=1,
            unit_id=unit_id,
            text=""
        ))
        return issues

    for j in range(len(source_lines)):
        src_line = source_lines[j]
        tgt_line = target_lines[j]

        src_strip = src_line.strip()
        tgt_strip = tgt_line.strip()

        src_leading = re.match(r"^\s*", src_line).group()
        tgt_leading = re.match(r"^\s*", tgt_line).group()
        src_trailing = re.search(r"\s*$", src_line).group()
        tgt_trailing = re.search(r"\s*$", tgt_line).group()

        if src_leading != tgt_leading or src_trailing != tgt_trailing:
            issues.append(make_validation_issue(
                validator=validator_name,
                message=f"Line {j+1} has different whitespace formatting in target.",
                filename=filename,
                line=base_line_number,
                column_start=1,
                column_end=1,
                unit_id=unit_id,
                text=tgt_line.strip()
            ))
            continue

        src_tag = re.match(r"<\/?\w+", src_strip)
        tgt_tag = re.match(r"<\/?\w+", tgt_strip)

        if src_tag and tgt_tag:
            src_val = src_tag.group()
            tgt_val = tgt_tag.group()
            if not ((src_val == "<source" and tgt_val == "<target") or
                    (src_val == "</source" and tgt_val == "</target") or
                    (src_val == tgt_val)):
                issues.append(make_validation_issue(
                    validator=validator_name,
                    message=f"Line {j+1} starts with different tag: source='{src_val}', target='{tgt_val}'",
                    filename=filename,
                    line=base_line_number,
                    column_start=1,
                    column_end=1,
                    unit_id=unit_id,
                    text=tgt_line.strip()
                ))

    return issues
