import re
from utils import make_validation_issue

def check_duplicate_ids(filename, lines):
    """
    CHECK #7: Duplicate IDs and ID Sequences
    Check the XLIFF file for duplicate and misnumbered IDs.
    - <file> and <unit> elements must have globally unique IDs.
    - Within each <unit>:
      • <data> element IDs must be unique and follow a sequential pattern: baseName_1, baseName_2, etc., without gaps or duplicates.
      • <ph> and <pc> element IDs must be unique and also follow a single shared global sequence across both types (e.g., ph1, pc2, pc3, ph4).
    """
    print("CHECK #7: check_duplicate_ids v2 called for", filename)

    from lxml import etree

    validation_issues = []
    xml_string = "".join(lines)
    parser = etree.XMLParser(recover=True)
    tree = etree.fromstring(xml_string.encode("utf-8"), parser)
    ns = {"ns": "urn:oasis:names:tc:xliff:document:2.0"}

    global_ids = set()
    global_id_elements = tree.xpath("//ns:file | //ns:unit", namespaces=ns)

    for elem in global_id_elements:
        eid = elem.get("id")
        if eid in global_ids:
            validation_issues.append(make_validation_issue(
                validator="Duplicate IDs",
                message=f"Duplicate global ID: '{eid}'",
                filename=filename,
                line=elem.sourceline,
                column_start=1,
                column_end=1,
                unit_id=None,
                text=lines[elem.sourceline - 1].strip()
            ))
        else:
            global_ids.add(eid)

    for unit in tree.xpath("//ns:unit", namespaces=ns):
        unit_id = unit.get("id")
        local_data_ids = {}
        sequence_tracker = []

        for el in unit.xpath(".//ns:data", namespaces=ns):
            eid = el.get("id")
            if not eid:
                continue
            if eid in local_data_ids:
                validation_issues.append(make_validation_issue(
                    validator="Duplicate IDs",
                    message=f"Duplicate <data> ID in unit '{unit_id}': '{eid}'",
                    filename=filename,
                    line=el.sourceline,
                    column_start=1,
                    column_end=1,
                    unit_id=unit_id,
                    text=lines[el.sourceline - 1].strip()
                ))
            else:
                local_data_ids[eid] = el
                m = re.match(r"(.+?)_(\d+)$", eid)
                if m:
                    sequence_tracker.append((eid, m.group(1), int(m.group(2))))

        # Check data sequence gaps
        if sequence_tracker:
            base = sequence_tracker[0][1]
            expected = list(range(1, len(sequence_tracker) + 1))
            actual = sorted([n[2] for n in sequence_tracker])
            if expected != actual:
                validation_issues.append(make_validation_issue(
                    validator="ID Sequence",
                    message=f"<data> IDs in unit '{unit_id}' do not follow sequential pattern {base}_1, {base}_2, ...",
                    filename=filename,
                    line=unit.sourceline,
                    column_start=1,
                    column_end=1,
                    unit_id=unit_id,
                    text=lines[unit.sourceline - 1].strip()
                ))

        # Check pc/ph shared sequence
        sequence_ids = []
        for el in unit.xpath(".//ns:ph | .//ns:pc", namespaces=ns):
            eid = el.get("id")
            if not eid:
                continue
            match = re.match(r"([a-zA-Z]+)(\d+)$", eid)
            if match:
                tag, num = match.groups()
                sequence_ids.append((eid, tag, int(num), el))

        sequence_ids.sort(key=lambda x: x[2])
        expected_nums = list(range(1, len(sequence_ids) + 1))
        actual_nums = [x[2] for x in sequence_ids]

        if expected_nums != actual_nums:
            validation_issues.append(make_validation_issue(
                validator="ID Sequence",
                message=f"<ph>/<pc> IDs in unit '{unit_id}' must follow a shared sequential pattern like ph1, pc2, pc3, ph4",
                filename=filename,
                line=sequence_ids[0][3].sourceline if sequence_ids else unit.sourceline,
                column_start=1,
                column_end=1,
                unit_id=unit_id,
                text=lines[sequence_ids[0][3].sourceline - 1].strip() if sequence_ids else lines[unit.sourceline - 1].strip()
            ))

    return validation_issues
