import re
from lxml import etree
from utils import ValidationIssue
from utils import xliff_check

@xliff_check(7)
def check_duplicate_ids(filename, lines):
    """
    CHECK #7: Duplicate IDs and ID Sequences

    - <file> and <unit> elements must have globally unique IDs.

    - All <pc> and <ph> tag IDs in <source> must follow a strict sequential pattern (e.g., block_0, generic_1, generic_2).
    - Same for <target>, but counted separately.
    - No duplicate sequence numbers within each section.

    - If a <pc> or <ph> has a dataRefStart/dataRefEnd/dataRef, the referenced <data> ID must exist and match the same sequence number.
    - All <data> elements must be referenced by at least one tag.
    - No extra or missing <data> elements.
    """
    print("CHECK #7: check_duplicate_ids v12 called for", filename)
    issues = []

    parser = etree.XMLParser(recover=True)
    tree = etree.fromstring("".join(lines).encode("utf-8"), parser)
    ns = {"ns": "urn:oasis:names:tc:xliff:document:2.0"}

    for file in tree.xpath(".//ns:file", namespaces=ns):
        for unit in file.xpath(".//ns:unit", namespaces=ns):
            unit_id = unit.get("id")
            original_data = unit.find(".//ns:originalData", namespaces=ns)
            if original_data is None:
                continue

            data_ids = {}
            referenced_data_ids = set()

            for data in original_data.xpath(".//ns:data", namespaces=ns):
                data_id = data.get("id")
                if data_id:
                    if data_id in data_ids:
                        issues.append(ValidationIssue(
                            validator="Duplicate IDs",
                            message=f"Duplicate <data> ID in unit '{unit_id}': '{data_id}'",
                            filename=filename,
                            line=data.sourceline,
                            column_start=1,
                            column_end=1,
                            unit_id=unit_id,
                            text=lines[data.sourceline - 1].strip()
                        ))
                    data_ids[data_id] = data

            for lang in ["source", "target"]:
                seen_sequences = set()
                tags = unit.xpath(f".//ns:{lang}//ns:ph | .//ns:{lang}//ns:pc", namespaces=ns)

                for tag in tags:
                    tag_id = tag.get("id")
                    if not tag_id:
                        continue
                    match = re.match(r"(.+?)_(\d+)$", tag_id)
                    if not match:
                        issues.append(ValidationIssue(
                            validator="ID Format",
                            message=f"Invalid ID format: '{tag_id}' in {lang}",
                            filename=filename,
                            line=tag.sourceline,
                            column_start=1,
                            column_end=1,
                            unit_id=unit_id,
                            text=lines[tag.sourceline - 1].strip()
                        ))
                        continue

                    _, seq = match.groups()
                    seq_num = int(seq)
                    if seq_num in seen_sequences:
                        issues.append(ValidationIssue(
                            validator="ID Sequence",
                            message=f"Duplicate sequence number {seq_num} in {lang}",
                            filename=filename,
                            line=tag.sourceline,
                            column_start=1,
                            column_end=1,
                            unit_id=unit_id,
                            text=lines[tag.sourceline - 1].strip()
                        ))
                    seen_sequences.add(seq_num)

                    for attr in ["dataRef", "dataRefStart", "dataRefEnd"]:
                        ref_id = tag.get(attr)
                        if ref_id:
                            referenced_data_ids.add(ref_id)
                            if ref_id not in data_ids:
                                issues.append(ValidationIssue(
                                    validator="Missing Reference",
                                    message=f"Missing <data> element for reference '{ref_id}'",
                                    filename=filename,
                                    line=tag.sourceline,
                                    column_start=1,
                                    column_end=1,
                                    unit_id=unit_id,
                                    text=lines[tag.sourceline - 1].strip()
                                ))
                            else:
                                # Verify the sequence number matches
                                try:
                                    ref_seq = int(ref_id.rsplit("_", 1)[1])
                                    if seq_num != ref_seq:
                                        issues.append(ValidationIssue(
                                            validator="ID Sequence",
                                            message=f"Sequence mismatch: {tag_id} references {ref_id}",
                                            filename=filename,
                                            line=tag.sourceline,
                                            column_start=1,
                                            column_end=1,
                                            unit_id=unit_id,
                                            text=lines[tag.sourceline - 1].strip()
                                        ))
                                except Exception:
                                    continue

            # Check for unreferenced <data> elements
            for data_id, data_el in data_ids.items():
                if data_id not in referenced_data_ids:
                    issues.append(ValidationIssue(
                        validator="Unreferenced Data",
                        message=f"Unreferenced <data> element: '{data_id}'",
                        filename=filename,
                        line=data_el.sourceline,
                        column_start=1,
                        column_end=1,
                        unit_id=unit_id,
                        text=lines[data_el.sourceline - 1].strip()
                    ))

    return issues
